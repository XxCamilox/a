#include <iostream>
using namespace std;
int main() {
  string nom[5];
  double pes[5];
  double max=0;
  string gu="a";
  for(int i=0;i<5;i++){
    cout<<"Ingrese el nombre:"<<endl;
    cin>>nom[i];
    cout<<"Ingrese el peso:"<<endl;
    cin>>pes[i];
  }
  for(int i=0; i<5; i++){
    if(max<pes[i]){
      max=pes[i];
      gu=nom[i];
      }
    }
  cout<<"La persona con mas peso es: "<<gu<<endl;
}